#pragma once
#include <string>
#include <vector>

class function {
	std::string formula;
public:
	function(std::string formula);

	std::string getFormula() const {
		return formula;
	}

	void shortenFunction(const function& f);
	void convertIntoRPN(char s[], int l);

	virtual ~function();
};