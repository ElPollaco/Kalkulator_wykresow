#include <iostream>
#include "function.h"

function::function(std::string f) : formula(f){
	shortenFunction(*this);
}

function::~function() {};