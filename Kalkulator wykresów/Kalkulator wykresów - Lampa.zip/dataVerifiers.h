#pragma once
#include <string>

extern std::string s;
extern char c;

bool isLetter(char);
bool isOperator(char);
bool isSpecialFunction(std::string);
int operatorPriority(char);