#include <iostream>
#include <string>
#include <Windows.h>
#include "function.h"

int main() {
	setlocale(LC_ALL, " ");

	function f1("y = x");
	function f2("y = x + 1");
	function f3("y = 5x - 3");
	function f4("y = 8x^2 + 4");
	function f5("y = 11x^2 + 4x - 5");
	function f6("y = 10x^3 / 4 + (2 / 5x)/(7/9x) - 3x^2 / 4x");
	function f7("y = (100x^5 - 2) - 8x * (5x * 3)");
	function f8("y = (10x^2 - 4)12x");
	function f9("y = (1/5)/[(56 + 7^x) * (8x/5)/3x^2] + 8");
	function f10("y = 24[(1/x)[(56 + 7^x)13 - x^2 * (8x/5 + 3)(6 - 3x^2)] + 8]");
	function f11("f(x) = -(-(-(x^2+6)(5x + (-12-2)) + 4))-5");
	function f12("y = [1.5 / 2.25x[2^x^2 - 3x^2(13 - 3x) + 5] - x^3/(3/15)/9] + 0.01"); // ostatni znak mno�enia w z�ym miejscu przy zwrocie ONP
	function f13("f(x) = PI^e * 2x + 6");
	function f14("y = fact(x)");

	return 0;
}